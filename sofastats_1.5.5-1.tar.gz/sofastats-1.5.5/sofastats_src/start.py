"""
SOFA Statistics is released under the open source AGPL3 licence and the
copyright is held by Paton-Simpson & Associates Ltd.
"""
import logging
logging.basicConfig(level=logging.DEBUG)
import sys
from pathlib import Path

## modify sys.path to avoid using dist-package version if installed as well
parent = str(Path.cwd().parent)
logging.info(f"Putting parent {parent} into sys.path so we can run this from "
    "folder of start.py")
sys.path.insert(0, parent)

from sofastats import setup_sofastats, home

def main():
    try:
        logging.info('About to load Sofastats app')
        app = home.SofaApp()
        app.MainLoop()
    except Exception as e:
        logging.error(e)
        app = setup_sofastats.ErrMsgApp(e)
        app.MainLoop()
        del app


if __name__ == '__main__':
    main()
